export default function ConnectButton() {
    return <w3m-button />
}